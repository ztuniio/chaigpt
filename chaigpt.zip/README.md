# ChaiGPT Cafe & Restaurant — Website

A single self-contained website for ChaiGPT Cafe & Restaurant, Jamshoro. All styling, scripts, fonts (via Google Fonts) and photos are bundled into one file — `index.html` — so there is nothing else to upload and nothing to configure.

## What's in this folder

- `index.html` — the entire website (HTML, CSS, JavaScript, and all photos embedded directly in the file).

That's it. No build step, no dependencies, no database.

## Put it live on GitHub Pages (free hosting)

1. **Create a repository**
   Go to [github.com/new](https://github.com/new), name it whatever you like (e.g. `chaigpt-website`), and create it (public repos get free GitHub Pages hosting).

2. **Upload the file**
   On the repo's main page, click **"Add file" → "Upload files"**, drag in `index.html`, and commit it to the `main` branch.
   *(Rename it to exactly `index.html` if GitHub shows a different name — that exact filename is required for the homepage to load automatically.)*

3. **Turn on GitHub Pages**
   Go to **Settings → Pages** (left sidebar). Under "Build and deployment", set:
   - Source: **Deploy from a branch**
   - Branch: **main**, folder **/ (root)**

   Click **Save**.

4. **Visit your site**
   After a minute or two, GitHub will show a link like:
   `https://yourusername.github.io/chaigpt-website/`
   That's your live website.

## Using your own domain (optional)

If you own a domain (e.g. `chaigpt.pk`):
1. In **Settings → Pages**, enter it under "Custom domain" and save.
2. At your domain registrar, add a `CNAME` record pointing to `yourusername.github.io`.
3. Wait for DNS to propagate (can take a few hours), then check "Enforce HTTPS" back in GitHub Pages settings once it's available.

## Making future edits

- Small text/price changes: click the pencil (✎) icon on `index.html` directly on GitHub to edit and commit — the live site updates within a minute or two.
- Bigger changes (new photos, new sections): easiest to come back here and ask Claude to make the changes, then re-upload the updated `index.html` the same way (Step 2 above) to overwrite the old one.

## Notes

- The page loads its fonts (Fraunces, Caveat, Figtree) from Google Fonts over the internet — this is normal and works automatically once the site is live, no setup needed.
- All photos are embedded directly in `index.html`, so the file is about 1.8 MB. This is fine for GitHub Pages and loads quickly on a normal connection, but if you ever want a faster-loading site, the photos could be split into separate image files down the line.
